import "dotenv/config";
import express from "express";
import dbconnection from "./config/db.js";
import userRoutes from "./routes/userRoutes.js";

const app = express();
const port = process.env.PORT;

//MIDDLEWARE
app.use(express.json());

//DB connection
dbconnection.connection();

//Routes
app.use("/api",userRoutes);

app.listen(port,function(){
    console.log(`server is running at http://localhost:${port}`);
});